//
//  TestCaseDemoTests.swift
//  TestCaseDemoTests
//
//  Created by Pavithra G. Jayanna on 05/05/16.
//  Copyright © 2016 Pavithra G. Jayanna. All rights reserved.
//

import XCTest
@testable import TestCaseDemo

class TestCaseDemoTests: XCTestCase
{
    var vc: ViewController!
    override func setUp()
    {
        super.setUp()
        vc = ViewController()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample()
    {
        
        
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testDoSomething()
    {
        //XCTAssertNil(vc.DisplaySum(10, b: 10), "some msg")
        XCTAssertNotNil(vc.DisplaySum(10, b: 10), "some msg")
        
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock
            {
              XCTAssertNotNil(self.vc.DisplaySum(10, b: 10), "some msg")
                // Put the code you want to measure the time of here.
        }
    }
    
}
